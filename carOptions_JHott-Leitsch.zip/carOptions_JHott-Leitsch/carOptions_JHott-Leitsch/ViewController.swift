//
//  ViewController.swift
//  carOptions_JHott-Leitsch
//
//  Created by student on 2/12/17.
//  Copyright © 2017 jhott-leitsch. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var engineButton: UIButton!
    @IBOutlet weak var colorButton: UIButton!
    @IBOutlet weak var interiorButton: UIButton!
    @IBOutlet weak var tireButton: UIButton!
    @IBOutlet weak var stereoButton: UIButton!
    
    
    @IBAction func engineButton(_ sender: UIButton) {
        let controller = UIAlertController(title: "Pick your engine", message:nil, preferredStyle: .actionSheet)
        
        let yesAction = UIAlertAction(title: "1.8 L 4-cylinder", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "1.8 L added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        let yesAction2 = UIAlertAction(title: "2.0 L 4-cylinder", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "2.0 L added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        
        let noAction = UIAlertAction(title: "Cancel",
                                     style: .cancel, handler: nil)
        
        controller.addAction(yesAction)
        controller.addAction(yesAction2)
        controller.addAction(noAction)
        
        if let ppc = controller.popoverPresentationController{
            ppc.sourceView = sender
            ppc.sourceRect = sender.bounds
            ppc.permittedArrowDirections = .down
        }
        
        self.present(controller, animated: true, completion: nil)
        
    }
    
    @IBAction func colorButton(_ sender: UIButton) {
        let controller = UIAlertController(title: "Pick your color", message:nil, preferredStyle: .actionSheet)
        
        let yesAction = UIAlertAction(title: "Black", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "Color Black added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        
        let yesAction2 = UIAlertAction(title: "Red", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "Color Red added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        
        let yesAction3 = UIAlertAction(title: "Blue", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "Color Blue added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        
        let yesAction4 = UIAlertAction(title: "White", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "Color White added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        let noAction = UIAlertAction(title: "Cancel",
                                     style: .cancel, handler: nil)
        
        controller.addAction(yesAction)
        controller.addAction(yesAction2)
        controller.addAction(yesAction3)
        controller.addAction(yesAction4)
        controller.addAction(noAction)
        
        if let ppc = controller.popoverPresentationController{
            ppc.sourceView = sender
            ppc.sourceRect = sender.bounds
            ppc.permittedArrowDirections = .down
        }
        
        self.present(controller, animated: true, completion: nil)
        
    }
    
    
    @IBAction func interiorButton(_ sender: UIButton) {
        let controller = UIAlertController(title: "Pick your interior", message:nil, preferredStyle: .actionSheet)
        
        let yesAction = UIAlertAction(title: "Black Tweed", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "Black Tweed added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        let yesAction2 = UIAlertAction(title: "Grey Tweed", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "Grey Tweed added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        
        let noAction = UIAlertAction(title: "Cancel",
                                     style: .cancel, handler: nil)
        
        controller.addAction(yesAction)
        controller.addAction(yesAction2)
        controller.addAction(noAction)
        
        if let ppc = controller.popoverPresentationController{
            ppc.sourceView = sender
            ppc.sourceRect = sender.bounds
            ppc.permittedArrowDirections = .down
        }
        
        self.present(controller, animated: true, completion: nil)
        
    }
    
    
    @IBAction func tireButton(_ sender: UIButton) {
        let controller = UIAlertController(title: "Pick your tires", message:nil, preferredStyle: .actionSheet)
        
        let yesAction = UIAlertAction(title: "Stock Rims", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "Stock Rims added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        let yesAction2 = UIAlertAction(title: "Black Carbonite Rims", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "Black Carbonite Rims added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        
        let noAction = UIAlertAction(title: "Cancel",
                                     style: .cancel, handler: nil)
        
        controller.addAction(yesAction)
        controller.addAction(yesAction2)
        controller.addAction(noAction)
        
        if let ppc = controller.popoverPresentationController{
            ppc.sourceView = sender
            ppc.sourceRect = sender.bounds
            ppc.permittedArrowDirections = .down
        }
        
        self.present(controller, animated: true, completion: nil)
        
    }
    
    @IBAction func stereoButton(_ sender: UIButton) {
        let controller = UIAlertController(title: "Pick your stereo", message:nil, preferredStyle: .actionSheet)
        
        let yesAction = UIAlertAction(title: "Stock stereo", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "Stock stereo added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        let yesAction2 = UIAlertAction(title: "Sirius Radio", style: .destructive, handler: {
            action in let msg = ""
            let controller2 = UIAlertController(
                title: "Sirius Radio added to car",
                message: msg, preferredStyle: .alert)
            
            let cancleAction = UIAlertAction(
                title: "Continue",
                style: .cancel,
                handler: nil)
            
            controller2.addAction(cancleAction)
            self.present(controller2, animated: true, completion: nil)
        })
        
        let noAction = UIAlertAction(title: "Cancel",
                                     style: .cancel, handler: nil)
        
        controller.addAction(yesAction)
        controller.addAction(yesAction2)
        controller.addAction(noAction)
        
        if let ppc = controller.popoverPresentationController{
            ppc.sourceView = sender
            ppc.sourceRect = sender.bounds
            ppc.permittedArrowDirections = .down
        }
        
        self.present(controller, animated: true, completion: nil)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

